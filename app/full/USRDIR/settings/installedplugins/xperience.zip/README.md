## About the plugin

This plugin adds a new skin for Movian (https://github.com/andoma/movian).

## License

Some resources (i.e. images) belong to either Movian (https://github.com/andoma/movian) or to the skin Xperience1080 for Kodi (https://github.com/vonH/skin.xperience1080).
